// // const express = require('express');
// // const router = express.Router();

// // router.get("/addTravel", async (req, res) => {

// //     res.render("addTravel");
 
// // });



// // Import necessary modules
// const express = require('express');
// const router = express.Router();

// const travelController = require('../controllers/travelController');

// router.post('/travel', travelController.addTravel);
// // Handle POST request for '/addTravel'
// router.post('/addTravel', (req, res) => {
//   // Extract data from the request body
//   const { travelName, travelDate, travelLocation } = req.body;

//   // Perform necessary operations with the data (e.g., save to database)

//   // Send a response back to the client
//   res.send('Travel added successfully');
// });

// // Export the router
// module.exports = router;




// router.get('/', travelController.getHome);
// router.get('/addTravel', travelController.getAddTravel);
// router.post('/addTravel', travelController.postAddTravel);

// module.exports = router;


// const express = require('express');
// const router = express.Router();
// const travelController = require('../controllers/travelController');

// // Handle GET request for '/'
// router.get('/', travelController.getHome);

// // Handle GET request for '/addTravel'
// router.get('/addTravel', travelController.getAddTravel);

// // Handle POST request for '/addTravel'
// router.post('/addTravel', travelController.postAddTravel);

// module.exports = router;

const express = require('express');
const router = express.Router();
const travelController = require('../controllers/travelController');

// Handle GET request for '/'
router.get('/', travelController.getHome);

// Handle GET request for '/addTravel'
router.get('/addTravel', travelController.getAddTravel);

// Handle POST request for '/addTravel'
router.post('/addTravel', travelController.postAddTravel);

module.exports = router;

