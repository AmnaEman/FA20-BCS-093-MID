// // // // const express = require('express');
// // // // const mongoose = require('mongoose');
// // // // const travelRoutes = require('./routes/travelRoutes');
// // // // const homeRoutes = require('./routes/home');

// // // // const methodOverride = require('method-override');
// // // // const app = express();
// // // // const port = 3000;

// // // const express = require("express");
// // // const mongoose = require("mongoose");
// // // const methodOverride = require("method-override");
// // // const path = require("path");
// // // const travelRoutes = require('./routes/travelRoutes');
// // // const addTravelRouter = require('./routes/addTravel');
// // // // const contactRouter = require('./routes/contact');
// // // // const homeRouter = require('./routes/home');
// // // // const landingRouter = require('./routes/landing');
// // // // const registerRouter = require('./routes/register');
// // // // const productRouter = require('./routes/product');

// // // let app = express();
// // // app.use(express.static('public'));
// // // app.use(express.json());
// // // app.use(express.urlencoded({ extended: true }));
// // // app.use(methodOverride("_method")); 
// // // var expressLayouts = require("express-ejs-layouts");
// // // app.use(expressLayouts);
// // // app.set('view engine', 'ejs');
// // // app.set('views', path.join(__dirname, 'views'));




// // // app.use('/', addTravelRouter);
// // // // app.use('/', blogRouter);
// // // // app.use('/', contactRouter);
// // // // app.use('/', homeRouter);
// // // // app.use('/', landingRouter);
// // // // app.use('/', registerRouter);
// // // // app.use('/', aboutRouter);
// // // // app.use('/', productRouter); 

// // // app.get("/", function(req, res) {
// // //   res.render("home");
// // // });





// // //   app.listen(3000, () => {
// // //     console.log('Server is running on port 3000');
// // //   });


  


// // // // app.set('view engine', 'ejs');

// // // // mongoose.connect("mongodb://0.0.0.0:27017/travel_DB",{
// // // //   useNewUrlParser: true,
// // // //   useUnifiedTopology: true,
// // // //  }).then(()=> console.log("connected to mongoDB...")
// // // //  ).catch((error)=>console.log(error.message));


// // // // app.use(methodOverride('_method'));
// // // // app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies

// // // // // Render addTruck.ejs when accessing the root URL
// // // // app.get('/', (req, res) => {
// // // //   res.render('home');
// // // // });

// // // // // Define your truck routes
// // // // app.use('/travel', travelRoutes);

// // // // app.listen(port, () => {
// // // //   console.log(`Server is running on port ${port}`);
// // // // });


// // // Import necessary modules
// // const express = require('express');
// // const bodyParser = require('body-parser');
// // const travelRoutes = require('./routes/travelRoutes');

// // // Create an Express app
// // const app = express();

// // // Configure middleware
// // app.use(express.json());
// // app.use(bodyParser.urlencoded({ extended: false }));
// // app.use(bodyParser.json());
// // app.set('view engine', 'ejs');

// // // Configure routes
// // app.use('/', travelRoutes);

// // // Start the server
// // app.listen(3000, () => {
// //   console.log('Server is running on port 3000');
// // });
// // Import necessary modules
// const express = require('express');
// const bodyParser = require('body-parser');
// const travelRoutes = require('./routes/travelRoutes');

// // Create an Express app
// const app = express();

// // Configure middleware
// app.use(express.json());
// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());
// app.set('view engine', 'ejs');

// // Configure routes
// app.use('/addTravel', travelRoutes);

// // Start the server
// app.listen(3000, () => {
//   console.log('Server is running on port 3000');
// });


// // Import necessary modules
// const express = require('express');
// const bodyParser = require('body-parser');
// const travelRoutes = require('./routes/travelRoutes');

// // Create an Express app
// const app = express();

// // Configure middleware

// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());
// app.set('view engine', 'ejs');

// // Configure routes
// app.use('/', travelRoutes);

// // Start the server
// app.listen(3000, () => {
//   console.log('Server is running on port 3000');
// });
// Import necessary modules
// Import necessary modules
const express = require('express');
const bodyParser = require('body-parser');
const travelRoutes = require('./routes/travelRoutes');

// Create an Express app
const app = express();

// Configure middleware

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');

// Configure routes
app.use('/', travelRoutes);
const mongoose = require('mongoose');
mongoose
  .connect("mongodb://0.0.0.0:27017/travel_DB", { useNewUrlParser: true })
  .then(() => console.log("Connected to Mongo ...."))
  .catch((error) => console.log(error.message));
// Start the server
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
