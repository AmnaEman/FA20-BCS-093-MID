const mongoose = require('mongoose');


var travelSchema = mongoose.Schema({
    Email: String,
    Departure_time: String,
    Arrival_time: String,
    Price: String
  });
  const travel = mongoose.model("travels", travelSchema);
  module.exports = travel;