// const express = require('express');
// const router = express.Router();
// const Travel = require('../models/travel');

// // GET
// // router.get('/', async (req, res) => {
// //   try {
// //     const travels = await Travel.find();
// //     res.render('travelview', { travels });
// //   } catch (error) {
// //     console.log('Error retrieving travels:', error);
// //     res.status(500).send('Internal Server Error');
// //   }
// // });

// // GET
// router.get('/add', (req, res) => {
//   res.render('addTravel');
// });

// // POST
// // router.post('/', async (req, res) => {
// //   try {
// //     const { Email,Departure_time , Arrival_time,Price } = req.body;
// //     const newTravel = new Travel({  Email,Departure_time , Arrival_time,Price });
// //     await newTravel.save();
// //     res.redirect('/travel');
// //   } catch (error) {
// //     console.log('Error adding travel:', error);
// //     res.status(500).send('Internal Server Error');
// //   }
// // });

// // DELETE
// router.delete('/:id', async (req, res) => {
//     try {
//       const { id } = req.params;
//       await Travel.findByIdAndDelete(id);
//       res.redirect('/travel');
//     } catch (error) {
//       console.log('Error deleting travel:', error);
//       res.status(500).send('Internal Server Error');
//     }
//   });
  
// module.exports = router;

const express = require('express');
const router = express.Router();
const travelController = require('../controllers/travelController');

// Handle GET request for '/'
router.get('/', travelController.getHome);

// Handle GET request for '/addTravel'
router.get('/addTravel', travelController.getAddTravel);

// Handle POST request for '/addTravel'
router.post('/addTravel', travelController.addTravel);

module.exports = router;