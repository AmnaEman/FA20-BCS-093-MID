email=document.getElementById("floatingInput");
password=document.getElementById("floatingPassword");

function validate(){
    console.log("btnclicked")
    if(email.value){
        email.classList.remove("error");
        email.classList.remove("bg-danger");
        email.classList.add("success");
        email.classList.add("bg-success");
    }

    else{
        email.classList.remove("bg-success");
        email.classList.remove("success");
        email.classList.add("error");
        email.classList.add("bg-danger");

    }

    if(password.value){
        password.classList.remove("bg-danger");
        password.classList.remove("error");
        password.classList.add("success");
        password.classList.add("bg-success");
    }

    else{
        password.classList.remove("bg-success");
        password.classList.remove("success");
        password.classList.add("error");
        password.classList.add("bg-danger");

    }
}