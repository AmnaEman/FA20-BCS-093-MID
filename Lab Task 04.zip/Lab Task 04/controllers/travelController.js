
  
// // exports.getHome = (req, res) => {
// //     // Render the home view
// //     res.render('home');
// //   };
  
// //   exports.getAddTravel = (req, res) => {
// //     // Render the addTravel view
// //     res.render('addTravel');
// //   };
  
// //   exports.postAddTravel = (req, res) => {
// //     // Extract data from the request body
// //     const { Email, Departure_time, Arrival_time, Price } = req.body;
  
// //     // Perform necessary operations with the data (e.g., save to database)
  
// //     // Return a response or redirect as needed
// //     res.redirect('/');
// //   };
  
  

// //   // Add a new travel record
// // exports.addTravel = function(req, res) {
// //     // Get the request body data
// //     const { Email, Departure_time, Arrival_time, Price } = req.body;
  
// //     // Create a new travel object
// //     const newTravel = {
// //       Email,
// //       Departure_time,
// //       Arrival_time,
// //       Price 
// //     };
  
// //     // Save the new travel object to the database
// //     // Replace this code with your database logic to save the travel record
  
// //     // Send a response indicating the travel record was added successfully
// //     res.status(201).json({ message: 'Travel record added successfully' });
// //   };
  
  

// const getHome = (req, res) => {
//     // Add your logic here to render the home page or perform any other operations
//     res.render('home');
//   };
  
//   const getAddTravel = (req, res) => {
//     // Add your logic here to render the add travel page or perform any other operations
//     res.render('addTravel');
//   };
  
//   const addTravel = (req, res) => {
//     // Retrieve data from the request body
//     const { destination, startDate, endDate } = req.body;
  
//     // Add your logic here to save the travel entry to a database or perform any other operations
  
//     // Respond with a success message or redirect to another page
//     res.send('Travel entry added successfully');
//   };
  
//   module.exports = {
//     getHome,
//     getAddTravel,
//     addTravel,
//   };
  
exports.getHome = (req, res) => {
    // Render the home view
    res.render('home');
  };
  
  exports.getAddTravel = (req, res) => {
    // Render the addTravel view
    res.render('addTravel');
  };
  
  exports.postAddTravel = (req, res) => {
    // Extract data from the request body
    const { Email, Departure_time, Arrival_time, Price } = req.body;
  
    // Perform necessary operations with the data (e.g., save to database)
  
    // Return a response or redirect as needed
    res.redirect('/');
  };
  
  
  
  exports.addTravel = (req, res) => {
    // Extract data from the request body
    const { Email, Departure_time, Arrival_time, Price } = req.body;
  
    // Perform any necessary data validation or processing
  
    // Create a new travel record using the extracted data
  
    // Return a response or redirect as needed
  };