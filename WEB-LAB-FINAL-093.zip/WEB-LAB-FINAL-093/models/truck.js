const mongoose = require('mongoose');

const truckSchema = new mongoose.Schema({
  number: {
    type: String,
    required: true
  },
  maxweight: {
    type: String,
    required: true
  },
  tyres: {
    type: String,
    required: true
  }
});

const Truck = mongoose.model('truck', truckSchema);

module.exports = Truck;
