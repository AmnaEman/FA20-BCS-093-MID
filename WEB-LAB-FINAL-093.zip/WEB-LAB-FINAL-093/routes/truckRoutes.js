const express = require('express');
const router = express.Router();
const Truck = require('../models/truck');

// GET
router.get('/', async (req, res) => {
  try {
    const trucks = await Truck.find();
    res.render('truckview', { trucks });
  } catch (error) {
    console.log('Error retrieving trucks:', error);
    res.status(500).send('Internal Server Error');
  }
});

// GET
router.get('/add', (req, res) => {
  res.render('addTruck');
});

// POST
router.post('/', async (req, res) => {
  try {
    const { number, maxweight , tyres } = req.body;
    const newTruck = new Truck({ number, maxweight , tyres });
    await newTruck.save();
    res.redirect('/trucks');
  } catch (error) {
    console.log('Error adding truck:', error);
    res.status(500).send('Internal Server Error');
  }
});

// DELETE
router.delete('/:id', async (req, res) => {
    try {
      const { id } = req.params;
      await Truck.findByIdAndDelete(id);
      res.redirect('/trucks');
    } catch (error) {
      console.log('Error deleting truck:', error);
      res.status(500).send('Internal Server Error');
    }
  });
  
module.exports = router;
