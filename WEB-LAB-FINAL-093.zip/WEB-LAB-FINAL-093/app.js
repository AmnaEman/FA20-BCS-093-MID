const express = require('express');
const mongoose = require('mongoose');
const truckRoutes = require('./routes/truckRoutes');

const methodOverride = require('method-override');




const app = express();
const port = 3000;


app.set('view engine', 'ejs');

mongoose.connect('mongodb+srv://sania:12345@cluster0.tygobp8.mongodb.net/truck', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((error) => {
  console.log('Error connecting to MongoDB:', error);
});

app.use(methodOverride('_method'));
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies

// Render addTruck.ejs when accessing the root URL
app.get('/', (req, res) => {
  res.render('addTruck');
});

// Define your truck routes
app.use('/trucks', truckRoutes);

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
